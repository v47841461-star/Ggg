package com.printhome.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var nsd: NsdManager
    private val types = listOf("_ipp._tcp.", "_printer._tcp.", "_pdl-datastream._tcp.")
    private val listeners = mutableListOf<NsdManager.DiscoveryListener>()
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var busy = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
        nsd = getSystemService(NSD_SERVICE) as NsdManager
    }

    private val perms = buildList {
        add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add("android.permission.NEARBY_WIFI_DEVICES")
        if (Build.VERSION.SDK_INT >= 31) { add("android.permission.BLUETOOTH_SCAN"); add("android.permission.BLUETOOTH_CONNECT") }
    }

    private fun beginScan() {
        stopScan()
        types.forEach { discover(it) }
        web.postDelayed({ js("onScanDone()") }, 9000)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        beginScan()
    }

    private fun js(code: String) = web.evaluateJavascript(code, null)

    inner class Bridge {
        @JavascriptInterface
        fun startScan() = runOnUiThread {
            val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (need.isEmpty()) beginScan() else requestPermissions(need.toTypedArray(), 1)
        }

        @JavascriptInterface
        fun print() = runOnUiThread {
            val pm = getSystemService(PRINT_SERVICE) as PrintManager
            pm.print("PrintHome", web.createPrintDocumentAdapter("PrintHome"), PrintAttributes.Builder().build())
        }
    }

    private fun nextResolve() {
        if (busy || queue.isEmpty()) return
        busy = true
        nsd.resolveService(queue.removeFirst(), object : NsdManager.ResolveListener {
            override fun onResolveFailed(s: NsdServiceInfo, e: Int) = runOnUiThread { busy = false; nextResolve() }
            override fun onServiceResolved(s: NsdServiceInfo) = runOnUiThread {
                val host = s.host?.hostAddress ?: ""
                js("onPrinter(${JSONObject.quote(s.serviceName)},${JSONObject.quote(host)},${s.port})")
                busy = false; nextResolve()
            }
        })
    }

    private fun discover(type: String) {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(s: NsdServiceInfo) = runOnUiThread { queue.add(s); nextResolve() }
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        listeners.add(l)
        nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
    }

    private fun stopScan() {
        listeners.forEach { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listeners.clear(); queue.clear(); busy = false
    }

    override fun onDestroy() { stopScan(); super.onDestroy() }
}
