1. Установите Android Studio.
2. File > Open > выберите папку PrintHome, дождитесь Gradle Sync.
3. Подключите телефон по USB (включите «Отладку по USB») и нажмите Run.
4. Телефон и принтер должны быть в одной Wi-Fi сети.
5. Если принтер не виден в окне печати, установите «HP Print Service Plugin» из Google Play.
